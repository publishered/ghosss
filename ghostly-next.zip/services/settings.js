export default {
   API_URL: 'https://captchaallow.site/',
   // API_URL: 'http://push-t.gg/',
}