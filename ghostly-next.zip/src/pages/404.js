import ErrorContent from '@/components/errorPage/errorContent/ErrorContent'

const ErrorPage = () => {
   return <ErrorContent />
}

export default ErrorPage