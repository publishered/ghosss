import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const NotifyContainer = () => {
   return <ToastContainer
      theme="colored"
   />
}

export default NotifyContainer